function[S1,S2,T,p]=partitioning(data,num_class)

Thr=[];
c=1;
N=size(data,1);
E_set=[];
for j=2:N
    if data(j,2)~=data(j-1,2)
       if data(j,1)~=data(j-1,1)
          Thr(c)=(data(j,1)+data(j-1,1))/2;
          Mat(c)=j;
          vec1=1:j-1;
          vec2=j:N;
          Ent1=ClassEntropyofSubset_S(data(vec1,:),num_class);
          Ent2=ClassEntropyofSubset_S(data(vec2,:),num_class);
          E=(length(vec1)/N)*Ent1+(length(vec2)/N)*Ent2;
          E_set(c)=E;
          c=c+1;
       end
    end
end
if isempty(E_set)==1
    p=0;
    T=0;
    S1=data;
    S2=[];
else
    p=1;
   [~,I]=min(E_set);
   T=Thr(I);
   S1=data(1:Mat(I)-1,:);
   S2=data(Mat(I):N,:);
end

            