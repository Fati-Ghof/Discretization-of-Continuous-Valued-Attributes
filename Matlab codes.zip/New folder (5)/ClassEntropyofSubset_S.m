function Ent_S=ClassEntropyofSubset_S(data,num_class)

k=1;
for i=1:num_class
    val_data=sum(data(:,end)==i);
    if val_data~=0
        vec_class(k)=i; % class numbers in data
        k=k+1;
    end
end

Num_SamPerClass=zeros(1,length(vec_class));
for i=1:length(vec_class)
    Num_SamPerClass(i)=sum(data(:,end)==vec_class(i)); % the number of samples per class in data 
end

Ent_s=0;
for i=1:length(vec_class)
    Ent_s=Ent_s+(Num_SamPerClass(i)/sum(Num_SamPerClass))*log2(Num_SamPerClass(i)/sum(Num_SamPerClass));
end
Ent_S=-Ent_s;