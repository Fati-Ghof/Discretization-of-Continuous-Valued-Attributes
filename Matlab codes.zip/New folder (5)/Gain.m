function[g]=Gain(S,S1,S2,num_class)
N_s=size(S,1);
N_s1=size(S1,1);
N_s2=size(S2,1);
Ent_S=ClassEntropyofSubset_S(S,num_class);
Ent_S1=ClassEntropyofSubset_S(S1,num_class);
Ent_S2=ClassEntropyofSubset_S(S2,num_class);


g=Ent_S-(N_s1/N_s)*Ent_S1-(N_s2/N_s)*Ent_S2;