 clc,
 clear all,

A1=train_data;
E1=test_data;
num_class=2;
[N,num_fea]=size(A1(:,1:end-1));
for i=1:num_fea
    sorted_fea=sortrows(A1,i);
    data=[sorted_fea(:,i),sorted_fea(:,num_fea+1)];
    Center=[];
    [Center,TT]=algorithm(data,num_class,N); 
    Cen{1}{i}=Center;
    TT=[TT,max(sorted_fea(:,1))];
    for i3=1:length(E1(:,i))
        diff=(TT-E1(i3,i));
        diff(diff<0)=10^20;
        [v,ind]=min(diff);
        Testdata_d(i3,i)=Center(ind);
    end
    for i4=1:length(A1(:,i))
        diff=(TT-A1(i4,i));
        diff(diff<0)=10^20;
        [v,ind]=min(diff);
        Traindata_d(i4,i)=Center(ind);
    end
end


Testdata_d(:,num_fea+1)=E1(:,num_fea+1);
Traindata_d(:,num_fea+1)=A1(:,num_fea+1);
Cen{1}{num_fea+1}=1:num_class;

