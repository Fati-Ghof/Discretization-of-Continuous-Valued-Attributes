function[d]=delta(S,S1,S2,num_class)
k=0;k1=0;k2=0;
for i=1:num_class
    val_s=sum(S(:,end)==i);
    val_s1=sum(S1(:,end)==i);
    val_s2=sum(S2(:,end)==i);
    if val_s~=0
        k=k+1;
    end
    if val_s1~=0
        k1=k1+1;
    end
    if val_s2~=0
        k2=k2+1;
    end
end
Ent_S=ClassEntropyofSubset_S(S,num_class);
Ent_S1=ClassEntropyofSubset_S(S1,num_class);
Ent_S2=ClassEntropyofSubset_S(S2,num_class);


d=log2(3^k-2)-(k*Ent_S-k1*Ent_S1-k2*Ent_S2);
