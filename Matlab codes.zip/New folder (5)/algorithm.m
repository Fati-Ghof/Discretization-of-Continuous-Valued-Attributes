function[Center,TT]=algorithm(data,num_class,N)   


int_data=data;
[S1,S2,T,p]=partitioning(data,num_class);
if p==1
   t=1;
   g=Gain(data,S1,S2,num_class);
   d=delta(data,S1,S2,num_class);
   if g>(log2(N-1)/N)+d/N;
      Mat(1,1)=1;
      S{1,1}=S1;
      S{1,2}=S2;
      Tre(1,1)=T;
      t=t+1;
   else
      Mat(1,1)=-1;
      S{1,1}=data;
      S{1,2}=[];
      t=t+1;
   end
else
    Mat(1,1)=-1;
    S{1,1}=data;
    S{1,2}=[];
    t=t+1;
end
m=sum(Mat(t-1,:)==-1);
q=size(Mat,2);
Mat(2,1:2)=0;
w=1;
while m~=q
      f=find(Mat(t-1,:)==-1);
      a=length(f);
      for i6=1:a
          if rem(f(i6),2)==0
             Mat(t,2*f(i6))=-1;
             Tre(t,2*f(i6))=10^5;
             Mat(t,2*f(i6)-1)=-1;
             Tre(t,2*f(i6)-1)=10^5;
          else
             Mat(t,2*f(i6))=-1;
             Tre(t,2*f(i6))=10^5;
             Mat(t,2*f(i6)-1)=-1;
             Tre(t,2*f(i6)-1)=10^5;
          end
      end
      for j=1:2^w
          if (a==0 ||Mat(t,j)~=-1)
              Mat(t,j)=1;
          end
      end
      f2=find(Mat(t,:)==1);
      a2=length(f2);
      for i1=a2:-1:1
          data=S{1,f2(i1)};
          N1=size(data,1);
          [S1,S2,T,p]=partitioning(data,num_class);
           if p==1
              if rem(f2(i1),2)~=0
                 g=Gain(data,S1,S2,num_class);
                 d=delta(data,S1,S2,num_class);
                 if g>(log2(N1-1)/N1)+d/N1;
                    Mat(t,f2(i1))=1;
                    S{1,2*f2(i1)-1}=S1;
                    S{1,2*f2(i1)}=S2;
                    Tre(t,f2(i1))=T;
                 else
                    Mat(t,f2(i1))=-1;
                    S{1,2*f2(i1)-1}=[];
                    S{1,2*f2(i1)}=[];
                    Tre(t,f2(i1))=10^5;
                 end 
              else
                    g=Gain(data,S1,S2,num_class);
                    d=delta(data,S1,S2,num_class);
                    if g>(log2(N1-1)/N1)+d/N1;
                       Mat(t,f2(i1))=1;
                       S{1,2*f2(i1)-1}=S1;
                       S{1,2*f2(i1)}=S2;
                       Tre(t,f2(i1))=T;
                    else
                       Mat(t,f2(i1))=-1;
                       S{1,2*f2(i1)-1}=[];
                       S{1,2*f2(i1)}=[];
                       Tre(t,f2(i1))=10^5;
                    end 
                end
            else
                if rem(f2(i1),2)~=0
                    Mat(t,f2(i1))=-1;
                    Tre(t,f2(i1))=10^5;
                    S{1,2*f2(i1)-1}=[];
                    S{1,2*f2(i1)}=[];
                else
                    Mat(t,f2(i1))=-1;
                    Tre(t,f2(i1))=10^5;
                    S{1,2*f2(i1)-1}=[];
                    S{1,2*f2(i1)}=[];
                end
            end
        end
        w=w+1;
        m=sum(Mat(t,:)==-1);
        q=size(Mat,2);
        t=t+1;
        Mat(t,1:2^(t-1))=0;
    end
   [ro,co]=find(Tre~=0);
   c=1;
   for ii=1:length(ro)
       if Tre(ro(ii),co(ii))~=10^5
          TT(c)=Tre(ro(ii),co(ii));
          c=c+1;
       end
   end
Mat_T=[min(int_data(:,1)), TT,max(int_data(:,1))];
Mat_T=sort(Mat_T);
TT=sort(TT);
for i5=1:length(TT)+1
    Center(i5)=(Mat_T(i5)+Mat_T(i5+1))/2;
end
